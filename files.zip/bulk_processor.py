"""
VNEXIS Bulk Processor — 레거시 데이터 자산화 파이프라인
실행: python bulk_processor.py --folder ./back_data
기능: 로컬 PDF/이미지 → Railway 백엔드 분석 → Supabase 저장

동일 피보험자 파일 합산 로직:
  파일명에서 이름 추출 → 같은 이름 파일들을 1건으로 묶어 전송
  예: "홍길동_진단서.pdf" + "홍길동_조직검사.pdf" → 1건 합산 분석
"""

import os
import sys
import json
import time
import hashlib
import logging
import argparse
import re
from pathlib import Path
from datetime import datetime
from collections import defaultdict

import requests
from tqdm import tqdm

# ── 설정 ──
API_URL = os.getenv(
    "VNEXIS_API_URL",
    "https://vnexis-backend-production.up.railway.app/api/vnexis/analyze"
)
SUPABASE_URL = os.getenv("SUPABASE_URL", "")
SUPABASE_KEY = os.getenv("SUPABASE_KEY", "")
SUPPORTED_EXT = {".pdf", ".png", ".jpg", ".jpeg", ".tif", ".tiff"}
REQUEST_TIMEOUT = 180  # 3분 (대용량 PDF 고려)
RETRY_COUNT = 2
RETRY_DELAY = 5  # 초

# ── 로깅 설정 ──
log_dir = Path("logs")
log_dir.mkdir(exist_ok=True)
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(log_dir / f"bulk_{timestamp}.log", encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
logger = logging.getLogger("bulk")


# ── 유틸리티 ──

def get_file_hash(file_path: str) -> str:
    """파일 SHA-256 해시 (중복 방지용)"""
    h = hashlib.sha256()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()[:16]  # 앞 16자만 사용


def extract_person_name(filename: str) -> str:
    """
    파일명에서 피보험자 이름 추출.
    규칙:
      1. 언더스코어(_) 또는 하이픈(-) 앞부분이 이름
      2. 한글 2~4글자 패턴 매칭
      3. 매칭 실패 시 파일명 전체를 그룹키로 사용
    예: "홍길동_진단서.pdf" → "홍길동"
        "김철수-조직검사결과.pdf" → "김철수"
        "진단서_2024.pdf" → "진단서_2024" (이름 아님, 단독 처리)
    """
    # 파일명에서 모든 한글 2~4자 토큰 추출
    # 일반 명사(진단서, 조직검사, 입원, 퇴원 등)는 제외
    COMMON_NOUNS = {
        '진단서', '조직검사', '결과', '판독', '차트', '의무기록', '퇴원', '입원',
        '수술', '검사', '소견서', '확인서', '통보서', '청구서', '영수증',
        '보험금', '심사', '통원', '외래', '응급', '병리', '처방전',
        '일산백병원', '서울대병원', '세브란스', '아산병원',  # 주요 병원명
    }

    stem = Path(filename).stem
    # 구분자로 분할
    tokens = re.split(r'[_\-\s]+', stem)

    # 한글 2~4자이면서 일반 명사가 아닌 토큰 → 이름 후보
    for token in tokens:
        if re.match(r'^[가-힣]{2,4}$', token) and token not in COMMON_NOUNS:
            return token

    # 이름 후보 없으면 파일명 전체를 그룹키로
    return stem


def group_files_by_person(folder: Path) -> dict:
    """
    폴더 내 파일을 피보험자 이름 기준으로 그룹화.
    Returns: { "홍길동": [path1, path2, ...], ... }
    """
    groups = defaultdict(list)
    for f in sorted(folder.rglob("*")):
        if f.suffix.lower() in SUPPORTED_EXT and f.is_file():
            person = extract_person_name(f.name)
            groups[person].append(f)
    return dict(groups)


def analyze_files(file_paths: list, insurance_info: dict = None) -> dict:
    """
    파일 목록을 백엔드 API로 전송하여 분석.
    여러 파일이면 첫 번째 파일로 전송 (백엔드가 단일 PDF 수신).
    TODO: 백엔드 멀티파일 지원 시 확장
    """
    # 현재 백엔드는 단일 PDF만 수신 → 가장 큰 파일(메인 의무기록) 선택
    main_file = max(file_paths, key=lambda f: f.stat().st_size)

    for attempt in range(RETRY_COUNT + 1):
        try:
            with open(main_file, "rb") as f:
                files = {"file": (main_file.name, f, "application/pdf")}
                data = {}
                if insurance_info:
                    data.update(insurance_info)

                response = requests.post(
                    API_URL,
                    files=files,
                    data=data,
                    timeout=REQUEST_TIMEOUT,
                )

            if response.status_code == 200:
                return response.json()
            else:
                logger.warning(
                    f"  API 응답 {response.status_code}: {response.text[:200]}"
                )
                if attempt < RETRY_COUNT:
                    time.sleep(RETRY_DELAY)
                    continue
                return None

        except requests.exceptions.Timeout:
            logger.warning(f"  타임아웃 (시도 {attempt + 1}/{RETRY_COUNT + 1})")
            if attempt < RETRY_COUNT:
                time.sleep(RETRY_DELAY)
            else:
                return None
        except Exception as e:
            logger.error(f"  요청 실패: {e}")
            return None

    return None


def save_to_supabase(case_id: str, result: dict, file_names: list) -> bool:
    """분석 결과를 Supabase claim_knowledge_base 테이블에 저장"""
    if not SUPABASE_URL or not SUPABASE_KEY:
        logger.info("  Supabase 미설정 → JSON 로컬 저장으로 대체")
        return False

    try:
        from supabase import create_client
        sb = create_client(SUPABASE_URL, SUPABASE_KEY)

        anon = result.get("Anonymous_Case_Data", {})
        timeline = result.get("Medical_Timeline", [])
        grade = result.get("Final_Grade", {})
        coding = result.get("Coding_Standard", {})
        coverage = result.get("Insurance_Coverage", {})
        opinion = result.get("Medical_Opinion", {})
        legal = result.get("Legal_Basis", [])

        data = {
            "case_id": case_id,
            "source_files": json.dumps(file_names, ensure_ascii=False),
            "disease_category": anon.get("Disease_Category", ""),
            "kcd_code": coding.get("KCD_Code", ""),
            "kcd_name": coding.get("KCD_Name", ""),
            "icd_code": coding.get("ICD_Code", ""),
            "who_classification": coding.get("WHO_Classification", ""),
            "coverage_type": coverage.get("Coverage_Type", ""),
            "meets_definition": coverage.get("Meets_Definition", False),
            "determination": grade.get("Determination", ""),
            "probability": grade.get("Probability", 0),
            "gap_analysis": coverage.get("Gap_Analysis", ""),
            "expert_assessment": opinion.get("Expert_Assessment", ""),
            "legal_basis_count": len(legal),
            "legal_basis_summary": json.dumps(
                [{"type": l.get("Type"), "case_id": l.get("Case_ID"),
                  "holding": l.get("Key_Holding", "")[:200]}
                 for l in legal],
                ensure_ascii=False
            ),
            "timeline_count": len(timeline),
            "key_keywords": json.dumps(
                anon.get("Key_Medical_Keywords", []), ensure_ascii=False
            ),
            "processed_at": datetime.now().isoformat(),
        }

        sb.table("claim_knowledge_base").upsert(data).execute()
        return True

    except Exception as e:
        logger.error(f"  Supabase 저장 실패: {e}")
        return False


def save_to_local_json(case_id: str, result: dict, output_dir: Path):
    """로컬 JSON 백업 저장"""
    output_dir.mkdir(exist_ok=True)
    out_path = output_dir / f"{case_id}.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)


def check_duplicate(case_id: str) -> bool:
    """Supabase에 이미 처리된 case_id인지 확인"""
    if not SUPABASE_URL or not SUPABASE_KEY:
        return False
    try:
        from supabase import create_client
        sb = create_client(SUPABASE_URL, SUPABASE_KEY)
        existing = sb.table("claim_knowledge_base") \
            .select("case_id") \
            .eq("case_id", case_id) \
            .execute()
        return len(existing.data) > 0
    except Exception:
        return False


# ── 메인 실행 ──

def main():
    parser = argparse.ArgumentParser(description="VNEXIS Bulk Processor")
    parser.add_argument(
        "--folder", type=str, required=True,
        help="처리할 PDF/이미지 폴더 경로 (예: ./back_data)"
    )
    parser.add_argument(
        "--output", type=str, default="./bulk_results",
        help="결과 JSON 저장 폴더 (기본: ./bulk_results)"
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="실제 API 호출 없이 파일 그룹핑만 확인"
    )
    args = parser.parse_args()

    folder = Path(args.folder)
    output_dir = Path(args.output)

    if not folder.exists():
        logger.error(f"폴더 없음: {folder}")
        sys.exit(1)

    # ── 파일 그룹핑 ──
    logger.info(f"\n{'='*60}")
    logger.info(f"VNEXIS Bulk Processor 시작")
    logger.info(f"대상 폴더: {folder.absolute()}")
    logger.info(f"{'='*60}\n")

    groups = group_files_by_person(folder)

    if not groups:
        logger.info("처리할 파일이 없습니다.")
        sys.exit(0)

    # 그룹핑 결과 미리보기
    logger.info(f"피보험자 기준 그룹핑: {len(groups)}건")
    logger.info("-" * 40)
    for person, files in groups.items():
        logger.info(f"  [{person}] {len(files)}개 파일")
        for f in files:
            logger.info(f"    └ {f.name} ({f.stat().st_size // 1024}KB)")
    logger.info("-" * 40)

    if args.dry_run:
        logger.info("\n[DRY RUN] 실제 분석 없이 종료.")
        return

    # ── 처리 시작 ──
    success, fail, skip = 0, 0, 0
    failed_cases = []

    pbar = tqdm(groups.items(), desc="전체 진행", unit="건")

    for person, files in pbar:
        # case_id: 파일 해시 기반
        combined_hash = hashlib.sha256(
            "|".join(sorted(f.name for f in files)).encode()
        ).hexdigest()[:12]
        case_id = f"BULK_{combined_hash}"

        pbar.set_postfix_str(f"{person} ({len(files)}파일)")
        logger.info(f"\n[{person}] 분석 시작 — {len(files)}개 파일, ID: {case_id}")

        # 중복 체크
        if check_duplicate(case_id):
            logger.info(f"  → 이미 처리됨. 스킵.")
            skip += 1
            continue

        # API 분석
        result = analyze_files(files)
        if not result:
            logger.error(f"  → 분석 실패!")
            fail += 1
            failed_cases.append({
                "person": person,
                "files": [f.name for f in files],
                "reason": "API 응답 없음 또는 에러",
            })
            time.sleep(2)  # API 부하 방지
            continue

        # 결과 로깅
        grade = result.get("Final_Grade", {})
        coding = result.get("Coding_Standard", {})
        timeline = result.get("Medical_Timeline", [])
        logger.info(
            f"  → 판정: {grade.get('Determination', '?')} | "
            f"KCD: {coding.get('KCD_Code', '?')} | "
            f"타임라인: {len(timeline)}건"
        )

        # 로컬 JSON 저장 (항상)
        save_to_local_json(case_id, result, output_dir)

        # Supabase 저장 (설정된 경우)
        file_names = [f.name for f in files]
        db_saved = save_to_supabase(case_id, result, file_names)
        if db_saved:
            logger.info(f"  → Supabase 저장 완료")
        else:
            logger.info(f"  → 로컬 JSON 저장 완료: {output_dir / case_id}.json")

        success += 1
        time.sleep(3)  # API Rate Limit 방지

    # ── 최종 보고 ──
    logger.info(f"\n{'='*60}")
    logger.info(f"VNEXIS Bulk Processor 완료")
    logger.info(f"{'='*60}")
    logger.info(f"총 그룹: {len(groups)}건")
    logger.info(f"성공: {success}건")
    logger.info(f"실패: {fail}건")
    logger.info(f"스킵(중복): {skip}건")

    if failed_cases:
        logger.info(f"\n실패 목록:")
        for fc in failed_cases:
            logger.info(f"  [{fc['person']}] {fc['files']} — {fc['reason']}")

        # 실패 로그 별도 저장
        fail_log = log_dir / f"failed_{timestamp}.json"
        with open(fail_log, "w", encoding="utf-8") as f:
            json.dump(failed_cases, f, ensure_ascii=False, indent=2)
        logger.info(f"\n실패 로그 저장: {fail_log}")

    logger.info(f"결과 JSON 폴더: {output_dir.absolute()}")
    logger.info(f"전체 로그: {log_dir / f'bulk_{timestamp}.log'}")


if __name__ == "__main__":
    main()

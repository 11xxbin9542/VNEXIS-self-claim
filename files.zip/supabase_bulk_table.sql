-- VNEXIS Claim Knowledge Base 테이블
-- Supabase SQL Editor에서 실행

create table if not exists claim_knowledge_base (
  id bigserial primary key,
  case_id text unique not null,
  source_files text,                    -- JSON 배열: 원본 파일명 목록
  disease_category text,                -- 암/뇌혈관/심혈관/입원의료비
  kcd_code text,
  kcd_name text,
  icd_code text,
  who_classification text,
  coverage_type text,                   -- 보험 커버리지 유형
  meets_definition boolean default false,
  determination text,                   -- 최종 판정
  probability float default 0,
  gap_analysis text,                    -- 보험사 주장 vs 반론
  expert_assessment text,               -- 전문가 소견
  legal_basis_count int default 0,
  legal_basis_summary text,             -- JSON: 판례 요약
  timeline_count int default 0,
  key_keywords text,                    -- JSON: 핵심 의학 키워드
  processed_at timestamp default now(),
  created_at timestamp default now()
);

-- 검색 인덱스
create index if not exists idx_cases_kcd on claim_knowledge_base(kcd_code);
create index if not exists idx_cases_category on claim_knowledge_base(disease_category);
create index if not exists idx_cases_determination on claim_knowledge_base(determination);
